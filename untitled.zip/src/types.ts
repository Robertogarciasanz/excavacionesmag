export type RoleType = 'user' | 'model';

export interface GroundingSource {
  uri: string;
  title: string;
}

export interface ChatMessage {
  id: string;
  role: RoleType;
  content: string;
  timestamp: string;
  groundingSources?: GroundingSource[];
  searchQueries?: string[];
  isError?: boolean;
}

export interface SystemRolePreset {
  id: string;
  name: string;
  description: string;
  systemInstruction: string;
  iconName: string;
  recommendedModel: string;
  defaultGrounding: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: string;
  messages: ChatMessage[];
  systemInstruction: string;
  model: string;
  useSearchGrounding: boolean;
  activeRolePresetId: string;
}
