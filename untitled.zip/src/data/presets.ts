import { SystemRolePreset } from '../types';

export const SPANISH_ROLE_PRESETS: SystemRolePreset[] = [
  {
    id: 'asistente_general',
    name: 'Asistente Polivalente',
    description: 'Atento, rápido y eficiente para todo tipo de preguntas y tareas diarias.',
    systemInstruction: 'Eres un asistente de inteligencia artificial amable, altamente capacitado y servicial. Responde siempre en español de forma clara, ordenada, estructurada con listas cuando sea conveniente, y con una ortografía impecable.',
    iconName: 'Bot',
    recommendedModel: 'gemini-3.6-flash',
    defaultGrounding: false
  },
  {
    id: 'investigador_web',
    name: 'Investigador y Búsqueda Web',
    description: 'Especialista en encontrar y sintetizar información actualizada con Google Search.',
    systemInstruction: 'Eres un investigador analítico experto. Utilizas la búsqueda en tiempo real para verificar datos recientes, noticias, acontecimientos y referencias. Responde siempre en español sintetizando los hallazgos principales y mencionando las fuentes y fechas cuando corresponda.',
    iconName: 'Search',
    recommendedModel: 'gemini-3.6-flash',
    defaultGrounding: true
  },
  {
    id: 'programador_experto',
    name: 'Desarrollador de Software',
    description: 'Especialista en programación, arquitectura de código, depuración y mejores prácticas.',
    systemInstruction: 'Eres un desarrollador Senior de software y arquitecto de sistemas. Proporcionas soluciones de código limpias, eficientes, bien comentadas y con buenas prácticas de tipado y modularidad. Responde en español explicando la lógica técnica detrás de cada solución.',
    iconName: 'Code2',
    recommendedModel: 'gemini-3.1-pro-preview',
    defaultGrounding: false
  },
  {
    id: 'tutor_educativo',
    name: 'Tutor Pedagógico',
    description: 'Explica temas difíciles de forma sencilla, didáctica y con ejemplos claros.',
    systemInstruction: 'Eres un educador y pedagogo paciente. Explicas conceptos complejos (física, matemáticas, historia, ciencia) utilizando analogías sencillas, ejemplos cotidianos y tono motivador en español. Invita al usuario a hacer preguntas para consolidar lo aprendido.',
    iconName: 'GraduationCap',
    recommendedModel: 'gemini-3.6-flash',
    defaultGrounding: false
  },
  {
    id: 'redactor_creativo',
    name: 'Redactor Creativo',
    description: 'Genera ideas, corrige estilos, redacta correos, artículos e historias persuasivas.',
    systemInstruction: 'Eres un especialista en redacción creativa, estrategias de comunicación y copywriting. Escribes textos atrayentes, bien estructurados, adaptados al tono y objetivo indicado en español.',
    iconName: 'PenTool',
    recommendedModel: 'gemini-3.6-flash',
    defaultGrounding: false
  },
  {
    id: 'personalizado',
    name: 'Rol Personalizado',
    description: 'Define tus propias instrucciones del sistema en español.',
    systemInstruction: 'Instrucciones personalizadas del sistema: Responde siempre en español adaptándote exactamente a este perfil.',
    iconName: 'Settings2',
    recommendedModel: 'gemini-3.6-flash',
    defaultGrounding: false
  }
];

export const AVAILABLE_MODELS = [
  {
    id: 'gemini-3.6-flash',
    name: 'Gemini 3.6 Flash',
    badge: 'Recomendado',
    description: 'Rápido, versátil e ideal para tareas generales y búsqueda web.'
  },
  {
    id: 'gemini-3.1-pro-preview',
    name: 'Gemini 3.1 Pro',
    badge: 'Pro / Razonamiento',
    description: 'Máxima potencia para tareas complejas, código y razonamiento avanzado.'
  },
  {
    id: 'gemini-3.1-flash-lite',
    name: 'Gemini 3.1 Flash Lite',
    badge: 'Ultra Rápido',
    description: 'Optimizado para respuestas ultrarrápidas y bajo consumo de latencia.'
  }
];

export const SAMPLE_PROMPTS = [
  {
    title: 'Noticias e Investigación',
    prompt: '¿Cuáles son los últimos descubrimientos en tecnología cuántica o astronomía este año?',
    icon: 'Globe'
  },
  {
    title: 'Explicación Didáctica',
    prompt: 'Explícame cómo funciona un motor de búsqueda usando una analogía sencilla.',
    icon: 'Sparkles'
  },
  {
    title: 'Programación',
    prompt: 'Escribe una función en TypeScript para realizar peticiones HTTP con reintentos automáticos.',
    icon: 'Code'
  },
  {
    title: 'Redacción y Estilo',
    prompt: 'Redacta un correo profesional solicitando una reunión de seguimiento con un cliente.',
    icon: 'MessageSquare'
  }
];
