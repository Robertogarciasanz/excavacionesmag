import React from 'react';
import { Bot, Globe, SlidersHorizontal, PlusCircle, Sparkles } from 'lucide-react';
import { AVAILABLE_MODELS } from '../data/presets';

interface HeaderProps {
  currentModel: string;
  onModelChange: (model: string) => void;
  useSearchGrounding: boolean;
  onSearchGroundingToggle: () => void;
  onOpenSettings: () => void;
  onNewChat: () => void;
  activeRoleName: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentModel,
  onModelChange,
  useSearchGrounding,
  onSearchGroundingToggle,
  onOpenSettings,
  onNewChat,
  activeRoleName,
}) => {
  return (
    <header className="sticky top-0 z-20 bg-white/90 backdrop-blur-md border-b border-slate-200/80 px-4 md:px-6 py-3">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
        {/* Logo and title */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-500 text-white flex items-center justify-center shadow-md shadow-indigo-100">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-slate-900 text-base md:text-lg leading-tight">
                Gemini AI Chatbot
              </h1>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200/60">
                <Sparkles className="w-3 h-3 mr-1 text-indigo-500" />
                {activeRoleName}
              </span>
            </div>
            <p className="text-xs text-slate-500 hidden md:block">
              Instrucciones del Sistema en español y Búsqueda Google Search
            </p>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2">
          {/* Model Selector Dropdown */}
          <div className="hidden lg:block relative">
            <select
              value={currentModel}
              onChange={(e) => onModelChange(e.target.value)}
              className="appearance-none bg-slate-50 hover:bg-slate-100/80 border border-slate-200 text-slate-800 text-xs font-medium rounded-xl px-3 py-2 pr-7 cursor-pointer focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              id="header-model-select"
            >
              {AVAILABLE_MODELS.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} ({m.badge})
                </option>
              ))}
            </select>
          </div>

          {/* Search Grounding Toggle */}
          <button
            onClick={onSearchGroundingToggle}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium border transition-all ${
              useSearchGrounding
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300 shadow-xs'
                : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border-slate-200'
            }`}
            title={useSearchGrounding ? 'Búsqueda Web activada' : 'Activar Búsqueda Web con Google Search'}
            id="header-grounding-toggle"
          >
            <Globe className={`w-3.5 h-3.5 ${useSearchGrounding ? 'text-emerald-600' : 'text-slate-400'}`} />
            <span className="hidden sm:inline">
              {useSearchGrounding ? 'Búsqueda Web: Activa' : 'Búsqueda Web: Off'}
            </span>
          </button>

          {/* Config / System Instruction button */}
          <button
            onClick={onOpenSettings}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-100 hover:bg-slate-200/80 text-slate-700 border border-slate-200/80 transition-colors"
            id="header-settings-btn"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-slate-600" />
            <span className="hidden md:inline">Instrucciones del Sistema</span>
          </button>

          {/* New Chat Button */}
          <button
            onClick={onNewChat}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-all active:scale-95"
            id="header-new-chat-btn"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Nuevo Chat</span>
          </button>
        </div>
      </div>
    </header>
  );
};
