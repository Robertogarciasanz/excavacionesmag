import React, { useState } from 'react';
import { SystemRolePreset, ChatSession } from '../types';
import { SPANISH_ROLE_PRESETS, AVAILABLE_MODELS } from '../data/presets';
import {
  Bot,
  Search,
  Code2,
  GraduationCap,
  PenTool,
  Settings2,
  X,
  Globe,
  Sliders,
  RotateCcw,
  Check,
  Plus,
  Trash2,
  MessageSquare
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  systemInstruction: string;
  onSystemInstructionChange: (instruction: string) => void;
  selectedRolePresetId: string;
  onSelectRolePreset: (preset: SystemRolePreset) => void;
  currentModel: string;
  onModelChange: (model: string) => void;
  useSearchGrounding: boolean;
  onSearchGroundingToggle: (value: boolean) => void;
  sessions: ChatSession[];
  activeSessionId: string;
  onSelectSession: (id: string) => void;
  onNewSession: () => void;
  onDeleteSession: (id: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  systemInstruction,
  onSystemInstructionChange,
  selectedRolePresetId,
  onSelectRolePreset,
  currentModel,
  onModelChange,
  useSearchGrounding,
  onSearchGroundingToggle,
  sessions,
  activeSessionId,
  onSelectSession,
  onNewSession,
  onDeleteSession,
}) => {
  const [activeTab, setActiveTab] = useState<'presets' | 'history'>('presets');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const getPresetIcon = (iconName: string) => {
    switch (iconName) {
      case 'Search':
        return <Search className="w-4 h-4 text-emerald-600" />;
      case 'Code2':
        return <Code2 className="w-4 h-4 text-amber-600" />;
      case 'GraduationCap':
        return <GraduationCap className="w-4 h-4 text-blue-600" />;
      case 'PenTool':
        return <PenTool className="w-4 h-4 text-purple-600" />;
      case 'Settings2':
        return <Settings2 className="w-4 h-4 text-slate-600" />;
      default:
        return <Bot className="w-4 h-4 text-indigo-600" />;
    }
  };

  const handlePresetClick = (preset: SystemRolePreset) => {
    onSelectRolePreset(preset);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  const currentPresetObj = SPANISH_ROLE_PRESETS.find((p) => p.id === selectedRolePresetId);

  return (
    <>
      {/* Backdrop for mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-30 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Drawer */}
      <aside
        className={`fixed top-0 right-0 bottom-0 z-40 w-full sm:w-96 bg-white border-l border-slate-200 shadow-2xl transition-transform duration-300 ease-out flex flex-col ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
        id="system-instruction-drawer"
      >
        {/* Drawer Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-indigo-600" />
            <h2 className="font-bold text-slate-900 text-base">Configuración e Instrucciones</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            id="btn-close-sidebar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-200 bg-slate-100/60 p-1 m-3 rounded-xl">
          <button
            onClick={() => setActiveTab('presets')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeTab === 'presets'
                ? 'bg-white text-indigo-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
            id="tab-presets-btn"
          >
            Instrucciones y Rol
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeTab === 'history'
                ? 'bg-white text-indigo-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
            id="tab-history-btn"
          >
            Historial ({sessions.length})
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {activeTab === 'presets' ? (
            <>
              {/* Role Presets Section */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
                  Seleccionar Rol del Chatbot (en Español)
                </label>
                <div className="grid grid-cols-1 gap-2">
                  {SPANISH_ROLE_PRESETS.map((preset) => {
                    const isSelected = selectedRolePresetId === preset.id;
                    return (
                      <button
                        key={preset.id}
                        onClick={() => handlePresetClick(preset)}
                        className={`w-full text-left p-3 rounded-xl border transition-all flex items-start gap-3 ${
                          isSelected
                            ? 'bg-indigo-50/70 border-indigo-300 ring-2 ring-indigo-500/20 shadow-xs'
                            : 'bg-white hover:bg-slate-50 border-slate-200/80'
                        }`}
                        id={`btn-preset-${preset.id}`}
                      >
                        <div className="p-2 rounded-lg bg-slate-100 shrink-0 mt-0.5">
                          {getPresetIcon(preset.iconName)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h3 className="text-xs font-bold text-slate-900">{preset.name}</h3>
                            {isSelected && <Check className="w-3.5 h-3.5 text-indigo-600 shrink-0" />}
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2">
                            {preset.description}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* SYSTEM INSTRUCTION Editor */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    SYSTEM_INSTRUCTION (Español)
                  </label>
                  {currentPresetObj && (
                    <button
                      onClick={() => onSystemInstructionChange(currentPresetObj.systemInstruction)}
                      className="text-[11px] text-indigo-600 hover:text-indigo-800 font-medium flex items-center gap-1"
                      title="Restaurar por defecto para este rol"
                      id="btn-reset-system-instruction"
                    >
                      <RotateCcw className="w-3 h-3" /> Restaurar
                    </button>
                  )}
                </div>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Esta instrucción define las reglas, rol y comportamiento del modelo en español. Puedes editarla en tiempo real.
                </p>
                <textarea
                  value={systemInstruction}
                  onChange={(e) => onSystemInstructionChange(e.target.value)}
                  rows={5}
                  className="w-full text-xs font-mono bg-slate-900 text-emerald-400 p-3 rounded-xl border border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 leading-relaxed resize-y"
                  placeholder="Escribe la instrucción del sistema en español..."
                  id="textarea-system-instruction"
                />
                {savedSuccess && (
                  <p className="text-xs text-emerald-600 font-medium flex items-center gap-1 animate-fade-in">
                    <Check className="w-3.5 h-3.5" /> Instrucciones del sistema actualizadas
                  </p>
                )}
              </div>

              {/* Gemini Model Selector */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <label className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                  Modelo Gemini Seleccionado
                </label>
                <div className="space-y-2">
                  {AVAILABLE_MODELS.map((model) => {
                    const isSelected = currentModel === model.id;
                    return (
                      <label
                        key={model.id}
                        className={`flex items-start gap-3 p-2.5 rounded-xl border cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-slate-900 text-white border-slate-800 shadow-sm'
                            : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
                        }`}
                        id={`radio-model-${model.id}`}
                      >
                        <input
                          type="radio"
                          name="model_selection"
                          value={model.id}
                          checked={isSelected}
                          onChange={() => onModelChange(model.id)}
                          className="mt-1 accent-indigo-500"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold">{model.name}</span>
                            <span
                              className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md ${
                                isSelected ? 'bg-indigo-500 text-white' : 'bg-slate-100 text-slate-600'
                              }`}
                            >
                              {model.badge}
                            </span>
                          </div>
                          <p
                            className={`text-[11px] mt-0.5 ${
                              isSelected ? 'text-slate-300' : 'text-slate-500'
                            }`}
                          >
                            {model.description}
                          </p>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Search Grounding Toggle */}
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Globe className="w-4 h-4 text-emerald-600" />
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">
                      Search Grounding (Google Search)
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Obtén respuestas con datos actualizados e hipervínculos
                    </span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={useSearchGrounding}
                  onChange={(e) => onSearchGroundingToggle(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500 accent-emerald-600 cursor-pointer"
                  id="checkbox-grounding-sidebar"
                />
              </div>
            </>
          ) : (
            /* History Tab */
            <div className="space-y-3">
              <button
                onClick={() => {
                  onNewSession();
                  setActiveTab('presets');
                }}
                className="w-full py-2.5 px-3 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors"
                id="btn-new-chat-history-tab"
              >
                <Plus className="w-4 h-4" /> Crear Nueva Conversación
              </button>

              <div className="space-y-1.5 pt-2">
                {sessions.map((sess) => {
                  const isActive = sess.id === activeSessionId;
                  return (
                    <div
                      key={sess.id}
                      className={`group flex items-center justify-between p-2.5 rounded-xl border text-xs transition-all ${
                        isActive
                          ? 'bg-indigo-50/80 border-indigo-200 text-indigo-950 font-medium'
                          : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
                      }`}
                      id={`session-item-${sess.id}`}
                    >
                      <button
                        onClick={() => onSelectSession(sess.id)}
                        className="flex-1 text-left truncate flex items-center gap-2 mr-2"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                        <span className="truncate">{sess.title}</span>
                      </button>

                      {sessions.length > 1 && (
                        <button
                          onClick={() => onDeleteSession(sess.id)}
                          className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-all"
                          title="Eliminar conversación"
                          id={`btn-delete-session-${sess.id}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </aside>
    </>
  );
};
