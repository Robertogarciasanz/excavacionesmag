import React from 'react';
import { SAMPLE_PROMPTS } from '../data/presets';
import { Sparkles, Globe, Code, MessageSquare, Bot, ArrowRight } from 'lucide-react';

interface EmptyStateProps {
  onSelectPrompt: (promptText: string) => void;
  activeRoleName: string;
  useSearchGrounding: boolean;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  onSelectPrompt,
  activeRoleName,
  useSearchGrounding,
}) => {
  const getPromptIcon = (iconName: string) => {
    switch (iconName) {
      case 'Globe':
        return <Globe className="w-5 h-5 text-indigo-600" />;
      case 'Code':
        return <Code className="w-5 h-5 text-emerald-600" />;
      case 'MessageSquare':
        return <MessageSquare className="w-5 h-5 text-purple-600" />;
      default:
        return <Sparkles className="w-5 h-5 text-amber-500" />;
    }
  };

  return (
    <div className="flex-1 flex items-center justify-center p-4 md:p-8">
      <div className="max-w-2xl w-full text-center space-y-8 my-auto py-8">
        {/* Welcome Header */}
        <div className="space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 border border-indigo-200/80 text-indigo-700 text-xs font-semibold">
            <Bot className="w-4 h-4 text-indigo-600" />
            <span>Rol Activo: {activeRoleName}</span>
            {useSearchGrounding && (
              <span className="ml-1 pl-2 border-l border-indigo-200 text-emerald-700 font-medium flex items-center gap-1">
                <Globe className="w-3 h-3 text-emerald-600" /> Grounding On
              </span>
            )}
          </div>

          <h2 className="text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight">
            ¿En qué te puedo ayudar hoy?
          </h2>
          <p className="text-sm md:text-base text-slate-600 max-w-lg mx-auto leading-relaxed">
            Escribe cualquier pregunta o selecciona una de las sugerencias predefinidas en español. Puedes personalizar las instrucciones del sistema en cualquier momento.
          </p>
        </div>

        {/* Sample Prompt Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-left">
          {SAMPLE_PROMPTS.map((item, idx) => (
            <button
              key={idx}
              onClick={() => onSelectPrompt(item.prompt)}
              className="p-4 rounded-2xl bg-white hover:bg-indigo-50/40 border border-slate-200/90 hover:border-indigo-300 shadow-xs hover:shadow-md transition-all group flex flex-col justify-between space-y-3"
              id={`btn-sample-prompt-${idx}`}
            >
              <div className="flex items-center justify-between w-full">
                <div className="p-2 rounded-xl bg-slate-50 group-hover:bg-indigo-100/60 transition-colors">
                  {getPromptIcon(item.icon)}
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition-all" />
              </div>

              <div>
                <h3 className="font-semibold text-slate-900 text-xs md:text-sm">{item.title}</h3>
                <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                  "{item.prompt}"
                </p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
