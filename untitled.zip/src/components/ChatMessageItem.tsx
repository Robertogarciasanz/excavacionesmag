import React, { useState } from 'react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { ChatMessage } from '../types';
import { Bot, User, Copy, Check, ExternalLink, Globe, AlertTriangle, RefreshCw } from 'lucide-react';

interface ChatMessageItemProps {
  message: ChatMessage;
  onRetry?: () => void;
}

export const ChatMessageItem: React.FC<ChatMessageItemProps> = ({ message, onRetry }) => {
  const [copied, setCopied] = useState(false);
  const isUser = message.role === 'user';

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className={`py-6 px-4 md:px-6 transition-colors ${
        isUser ? 'bg-slate-50/80 border-b border-slate-100/80' : 'bg-white border-b border-slate-100'
      }`}
      id={`msg-${message.id}`}
    >
      <div className="max-w-4xl mx-auto flex gap-4 md:gap-6 items-start">
        {/* Avatar */}
        <div
          className={`shrink-0 w-9 h-9 rounded-xl flex items-center justify-center font-medium shadow-xs ${
            isUser
              ? 'bg-slate-800 text-white'
              : message.isError
              ? 'bg-amber-100 text-amber-700 border border-amber-200'
              : 'bg-indigo-600 text-white shadow-indigo-200'
          }`}
        >
          {isUser ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
        </div>

        {/* Message Content */}
        <div className="flex-1 min-w-0 space-y-3">
          {/* Header info */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-sm text-slate-800">
                {isUser ? 'Tú' : 'Gemini AI'}
              </span>
              <span className="text-xs text-slate-400">{message.timestamp}</span>
            </div>

            {/* Action buttons */}
            {!isUser && (
              <div className="flex items-center gap-1">
                <button
                  onClick={handleCopy}
                  title="Copiar respuesta"
                  className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                  id={`btn-copy-${message.id}`}
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                </button>
                {message.isError && onRetry && (
                  <button
                    onClick={onRetry}
                    title="Reintentar"
                    className="p-1.5 text-amber-600 hover:bg-amber-50 rounded-lg transition-colors flex items-center gap-1 text-xs font-medium"
                    id={`btn-retry-${message.id}`}
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> Reintentar
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Text content / Error message */}
          {message.isError ? (
            <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200/80 text-amber-900 text-sm flex items-start gap-2.5">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-amber-950">Error en la respuesta</p>
                <p className="mt-0.5 text-amber-800/90 text-xs leading-relaxed">{message.content}</p>
              </div>
            </div>
          ) : isUser ? (
            <p className="text-slate-800 text-sm md:text-base leading-relaxed whitespace-pre-wrap">
              {message.content}
            </p>
          ) : (
            <div className="prose prose-slate prose-sm md:prose-base max-w-none prose-headings:font-semibold prose-headings:text-slate-900 prose-p:text-slate-700 prose-p:leading-relaxed prose-pre:bg-slate-900 prose-pre:text-slate-100 prose-pre:rounded-xl prose-code:text-indigo-600 prose-code:bg-indigo-50/80 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded-md prose-code:before:content-none prose-code:after:content-none">
              <Markdown remarkPlugins={[remarkGfm]}>{message.content}</Markdown>
            </div>
          )}

          {/* Search Grounding Metadata Section */}
          {!isUser && message.searchQueries && message.searchQueries.length > 0 && (
            <div className="mt-3 pt-3 border-t border-slate-100">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium mb-1.5">
                <Globe className="w-3.5 h-3.5 text-indigo-500" />
                <span>Búsquedas web realizadas:</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {message.searchQueries.map((query, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center px-2 py-0.5 rounded-md text-xs font-mono bg-slate-100 text-slate-600 border border-slate-200/60"
                  >
                    "{query}"
                  </span>
                ))}
              </div>
            </div>
          )}

          {!isUser && message.groundingSources && message.groundingSources.length > 0 && (
            <div className="mt-3 pt-3 border-t border-slate-100">
              <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium mb-2">
                <Globe className="w-3.5 h-3.5 text-indigo-600" />
                <span>Fuentes verificadas en Google Search ({message.groundingSources.length}):</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {message.groundingSources.map((source, idx) => (
                  <a
                    key={idx}
                    href={source.uri}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium bg-indigo-50/80 hover:bg-indigo-100 text-indigo-700 border border-indigo-200/60 transition-colors max-w-xs truncate group"
                    id={`link-source-${message.id}-${idx}`}
                  >
                    <span className="truncate">{source.title || source.uri}</span>
                    <ExternalLink className="w-3 h-3 text-indigo-400 group-hover:text-indigo-600 shrink-0" />
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
