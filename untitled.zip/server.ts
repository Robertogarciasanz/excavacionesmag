import express from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // Shared Gemini client setup on server
  const getGeminiClient = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('La clave GEMINI_API_KEY no está configurada en las variables de entorno.');
    }
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  };

  // Health check
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', hasApiKey: !!process.env.GEMINI_API_KEY });
  });

  // Chat endpoint
  app.post('/api/chat', async (req, res) => {
    try {
      const { messages, systemInstruction, model, useSearchGrounding, temperature } = req.body;

      if (!Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({ error: 'La lista de mensajes no puede estar vacía.' });
      }

      const ai = getGeminiClient();
      const selectedModel = model || 'gemini-3.6-flash';

      // Format contents for @google/genai
      const contents = messages.map((m: { role: string; content: string }) => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.content }],
      }));

      // Configuration
      const config: any = {
        systemInstruction: systemInstruction || 'Responde siempre en español de forma profesional, clara y estructurada.',
        temperature: typeof temperature === 'number' ? temperature : 0.7,
      };

      if (useSearchGrounding) {
        config.tools = [{ googleSearch: {} }];
      }

      const response = await ai.models.generateContent({
        model: selectedModel,
        contents,
        config,
      });

      const text = response.text || '';
      const candidate = response.candidates?.[0];
      const groundingChunksRaw = candidate?.groundingMetadata?.groundingChunks || [];
      const searchQueries = candidate?.groundingMetadata?.webSearchQueries || [];

      // Extract web sources from grounding metadata
      const groundingSources = groundingChunksRaw
        .map((chunk: any) => chunk.web)
        .filter((web: any) => web && web.uri)
        .map((web: any) => ({
          uri: web.uri,
          title: web.title || web.uri,
        }));

      return res.json({
        text,
        groundingSources,
        searchQueries,
      });
    } catch (err: any) {
      console.error('Error en /api/chat:', err);
      return res.status(500).json({
        error: err.message || 'Ocurrió un error inesperado al procesar la respuesta con Gemini.',
      });
    }
  });

  // Serve frontend
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Servidor Gemini Chatbot corriendo en http://localhost:${PORT}`);
  });
}

startServer();
